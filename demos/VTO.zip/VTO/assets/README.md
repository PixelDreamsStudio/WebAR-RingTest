# Model generation

.GLB 3D models are generated from .BLEND file using Blender 2.83:

* The .BLEND model file is opened,
* We select the main mesh in *Object Mode*
* We Click on *File/Export/GLTF 2.0*
* We keep default options except *Include/Selected Objects* (we check it to be sure to not export light, camera, or other unwanted item)



