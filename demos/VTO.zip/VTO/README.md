# Wrist and Ring VTO

To create your own wrist and ring VTO webapp, you can edit:

* `main.js`
* `index.html`

Please do not change the Helper (`../helpers/HandTrackerVTOThreeHelper.js`) without notifying WebAR.rocks.
There are some info about 3D models export [here](assets/)
